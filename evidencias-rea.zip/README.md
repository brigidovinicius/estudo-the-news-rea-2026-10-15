# Evidências do estudo

REA 6.5.0; Node 22.23.2. Três Evidence originais estão em rea/. static.json.gz contém o JSON estático completo comprimido, sem alteração do registro. E06 é complemento Playwright e não é resultado REA.

Os cenários de entrada estão em inputs/. Para reproduzir, com Node compatível: npm exec --yes --package=rea-agents@6.5.0 -- rea capture-browser-scenario inputs/home-scenario.json --format json

Ajuste apenas executable_path para um Chrome local. Para análise estática use a pasta source com o bundle fornecido, selecionando o arquivo JavaScript. IDs de Evidence novos podem mudar por ambiente ou artefato. O manifesto registra hashes dos arquivos exatos desta coleta.

As capturas são limitadas às condições registradas, sem login ou envio de formulário. Requisições automáticas do site podem aparecer em E01. Não inferir funcionamento de backend, dados comerciais ou confirmação de e-mail desses arquivos.
