import {chromium} from './rea-runtime/node_modules/playwright-core/index.mjs';
import {writeFile} from 'node:fs/promises';
const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
const results=[];
try{const ctx=await browser.newContext({viewport:{width:390,height:844},locale:'pt-BR',timezoneId:'America/Sao_Paulo'});const page=await ctx.newPage();page.setDefaultTimeout(12000);
 for(const path of ['/inscrever-minimal','/evento/agenda','/evento/indicar','/evento/patrocinar','/streak/missions','/redirect']){try{const response=await page.goto('https://thenewscc.com.br'+path,{waitUntil:'domcontentloaded',timeout:18000});await page.waitForTimeout(1500);const dom=await page.content();const text=await page.locator('body').innerText();results.push({path,url:page.url(),httpStatus:response?.status(),text,headings:await page.locator('h1,h2,h3').allTextContents(),horizontalOverflow:await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth)});if(path==='/inscrever-minimal')await page.screenshot({path:'outputs/assets/original-mobile.png',timeout:12000});}catch(e){results.push({path,error:e.message})}}
 await ctx.close();}finally{await browser.close();await writeFile('work/supplement-capture.json',JSON.stringify({tool:'Playwright complementar; não é Evidence do REA',date:'2026-10-15',results},null,2))}
console.log(results.map(r=>({path:r.path,url:r.url,error:r.error})))
